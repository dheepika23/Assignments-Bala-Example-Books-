package com.ns.bootwebapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootwebappApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootwebappApplication.class, args);
	}

}
