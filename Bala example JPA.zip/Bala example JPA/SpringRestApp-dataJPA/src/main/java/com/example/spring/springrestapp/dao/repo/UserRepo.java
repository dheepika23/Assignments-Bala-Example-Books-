package com.example.spring.springrestapp.dao.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.spring.springrestapp.dao.entity.UserInformation;

public interface UserRepo extends JpaRepository<UserInformation, String> {

}
