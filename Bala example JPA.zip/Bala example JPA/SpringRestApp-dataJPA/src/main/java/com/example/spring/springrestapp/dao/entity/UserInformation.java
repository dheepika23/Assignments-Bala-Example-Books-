package com.example.spring.springrestapp.dao.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;

import org.springframework.data.annotation.Id;

@Entity
@Table(name = "user_info")
public class UserInformation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "USER_ID")
    private Integer userId;

    @Column(name = "FIRST_NAME")
    @NotBlank(message = "first name can't be blank")
    private String firstName;
 
    @Column(name = "LAST_NAME")
    @NotBlank(message = "last name can't be blank")
    private String lastName;
 
   @Column(name = "EMAIL")
   @NotBlank(message = "email can't be blank")
   @Email(message = "invalid format")
    private String email;
 
    @Column(name = "ADDRESS")
    private String address;
 
    @Column(name = "PHONE")
    private Integer phone;



	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Integer getPhone() {
		return phone;
	}

	public void setPhone(Integer phone) {
		this.phone = phone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
}
