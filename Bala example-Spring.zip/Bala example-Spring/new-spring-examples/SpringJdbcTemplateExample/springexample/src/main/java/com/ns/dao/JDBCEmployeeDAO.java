package com.ns.dao;

import java.util.List;

import com.ns.Employee;

public interface JDBCEmployeeDAO {

	public void insert(Employee employee);
        public void update(Employee employee);
	public Employee findById(int id);
        public Employee findByName(String name);
	public List<Employee> findAll();
	public String findNameById(int id);
}
