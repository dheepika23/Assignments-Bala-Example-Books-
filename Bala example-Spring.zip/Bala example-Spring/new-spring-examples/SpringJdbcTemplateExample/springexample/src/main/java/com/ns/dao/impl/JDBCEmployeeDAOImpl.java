package com.ns.dao.impl;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

import com.ns.Employee;
import com.ns.dao.JDBCEmployeeDAO;

public class JDBCEmployeeDAOImpl implements JDBCEmployeeDAO {

    private DataSource dataSource;
    private JdbcTemplate jdbcTemplate;

    public void setDataSource(DataSource dataSource) {
        this.dataSource = dataSource;
        this.jdbcTemplate = new JdbcTemplate(dataSource);
    }

    @Override
    public void insert(Employee employee) {

        String sql = "INSERT INTO EMPLOYEE "
                + "(ID, NAME, AGE) VALUES (?, ?, ?)";

        //jdbcTemplate = new JdbcTemplate(dataSource);

        jdbcTemplate.update(sql, new Object[]{employee.getId(),
            employee.getName(), employee.getAge()
        });
    }

    @Override
    public void update(Employee employee) {

        String sql = "UPDATE EMPLOYEE SET NAME = ?, AGE = ? WHERE ID = ?";

        //jdbcTemplate = new JdbcTemplate(dataSource);

        jdbcTemplate.update(sql, new Object[]{
            employee.getName(), employee.getAge(), employee.getId()
        });
    }

    @Override
    public Employee findById(int id) {

        String sql = "SELECT * FROM EMPLOYEE WHERE ID = ?";

        //jdbcTemplate = new JdbcTemplate(dataSource);
        Employee employee = (Employee) jdbcTemplate.queryForObject(
                sql, new Object[]{id}, new BeanPropertyRowMapper(Employee.class));

        return employee;
    }

    @Override
    public List<Employee> findAll() {

        //jdbcTemplate = new JdbcTemplate(dataSource);
        String sql = "SELECT * FROM EMPLOYEE";

        List<Employee> employees = new ArrayList<Employee>();

        List<Map<String, Object>> rows = jdbcTemplate.queryForList(sql);
        for (Map row : rows) {
            Employee employee = new Employee();
            employee.setId(Integer.parseInt(String.valueOf(row.get("ID"))));
            employee.setName((String) row.get("NAME"));
            employee.setAge(Integer.parseInt(String.valueOf(row.get("AGE"))));
            employees.add(employee);
        }

        return employees;
    }

    public String findNameById(int id) {

        //jdbcTemplate = new JdbcTemplate(dataSource);
        String sql = "SELECT NAME FROM EMPLOYEE WHERE ID = ?";

        String name = (String) jdbcTemplate.queryForObject(
                sql, new Object[]{id}, String.class);

        return name;
    }

    @Override
    public Employee findByName(String name) {
        String sql = "SELECT * FROM EMPLOYEE WHERE NAME = ?";

        //jdbcTemplate = new JdbcTemplate(dataSource);
        Employee employee = (Employee) jdbcTemplate.queryForObject(
                sql, new Object[]{name}, new BeanPropertyRowMapper(Employee.class));

        return employee;
    }
}
