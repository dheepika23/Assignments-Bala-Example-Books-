package com.ns;


import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ns.dao.JDBCEmployeeDAO;
import java.util.List;

public class App {

    public static void main(String[] args) {

        try (ConfigurableApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml")) {

            JDBCEmployeeDAO jdbcEmployeeDAO = (JDBCEmployeeDAO) context.getBean("jdbcEmployeeDAO");

            Employee emplNew1 = new Employee("John", 23);
            jdbcEmployeeDAO.insert(emplNew1);
            Employee emplNew2 = new Employee("Mark", 43);
            jdbcEmployeeDAO.insert(emplNew2);
            List<Employee> employeeList = jdbcEmployeeDAO.findAll();
            System.out.println(" FindAll : " + employeeList);
            Employee emp = jdbcEmployeeDAO.findByName("Mark");
            System.out.println(" FindByName : " + emp);
            emp.setName("Mark Waugh");
            jdbcEmployeeDAO.update(emp);
            System.out.println(" FindAll : " + jdbcEmployeeDAO.findAll());
        }
   
    }
}
