/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ns.springjavaconfigapp;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

/**
 *
 * @author bramu
 */
public class SpringJavaConfigApp {
    public static void main(String[] args) {
        ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
        Greeting greetingBean = (Greeting)context.getBean("greeting");
        greetingBean.greet();
        greetingBean.setMessage("Hi, Howdy!");
        greetingBean.greet();
        
        Greeting greetingBean2 = (Greeting)context.getBean(com.ns.springjavaconfigapp.Greeting.class);
        greetingBean2.greet();
  
        Employee ram  = (Employee)context.getBean("employee");
        ram.setId("E001");
        ram.setName("Ram Manohar");
        ram.setSalary(10000.00f);
        System.out.println(ram);
        
        Employee kumar  = (Employee)context.getBean("employee");
        kumar.setId("E002");
        kumar.setName("Kumar Dharma");
        kumar.setSalary(15000.00f);
        System.out.println(kumar);
        
        System.out.println(ram);
        
        Employee mano  = (Employee)context.getBean("mano");
        System.out.println(mano);
    }
}
