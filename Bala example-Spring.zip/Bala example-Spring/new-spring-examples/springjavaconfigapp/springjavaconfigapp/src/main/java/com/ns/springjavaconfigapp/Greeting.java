/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ns.springjavaconfigapp;

/**
 *
 * @author bramu
 */
public class Greeting implements IGreeting {
    private String message =  null;
    
    public Greeting() {
        message = "Hello World!";
    }
    
    public void greet() {
        System.out.println(getMessage());
    }

    /**
     * @return the message
     */
    public String getMessage() {
        return message;
    }

    /**
     * @param message the message to set
     */
    public void setMessage(String message) {
        this.message = message;
    }
}
