/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ns.springtestapp;

/**
 *
 * @author bramu
 */
public class Employee {

    /**
     * @return the department
     */
    public Department getDepartment() {
        return department;
    }

    /**
     * @param department the department to set
     */
    public void setDepartment(Department department) {
        this.department = department;
    }

    /**
     * @return the id
     */
    public String getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the salary
     */
    public float getSalary() {
        return salary;
    }

    /**
     * @param salary the salary to set
     */
    public void setSalary(float salary) {
        this.salary = salary;
    }
    
    
    public String toString() {
        if (department == null) {
            return String.format("id is %s - name is %s - salary is %5.2f", 
                id, name, salary);
        }
        else {
            return String.format("id is %s - name is %s - salary is %5.2f \ndeptid is %s deptname is %s", 
                id, name, salary, department.getId(), department.getName());
        }      
    }
    
    private String id;
    private String name;
    private float salary;
    private Department department;
}
