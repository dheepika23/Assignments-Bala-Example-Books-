package com.ns.demo.dao;

import java.util.List;

import com.ns.demo.model.EmployeeVO;

public interface EmployeeDAO 
{
	public List<EmployeeVO> getAllEmployees();
}