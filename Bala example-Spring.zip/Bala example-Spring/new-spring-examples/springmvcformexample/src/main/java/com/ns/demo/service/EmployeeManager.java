package com.ns.demo.service;

import java.util.List;

import com.ns.demo.model.EmployeeVO;

public interface EmployeeManager 
{
	public List<EmployeeVO> getAllEmployees();
}
