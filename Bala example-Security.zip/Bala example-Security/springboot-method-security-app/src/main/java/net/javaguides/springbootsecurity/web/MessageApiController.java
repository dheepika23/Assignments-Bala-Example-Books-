package net.javaguides.springbootsecurity.web;

import java.net.URI;

import javax.annotation.security.RolesAllowed;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;
import net.javaguides.springbootsecurity.entities.*;

import net.javaguides.springbootsecurity.repositories.*;

@RestController
@RequestMapping("/api/messages")
public class MessageApiController {

	@Autowired
	private MessageRepository messageRepository;
	
  //@Secured("ROLE_ADMIN") 
  //@Secured("ROLE_USER") 
  @RolesAllowed({ "ROLE_USER", "ROLE_ADMIN" })
  @RequestMapping(value="/{id}", method=RequestMethod.GET, produces="application/json")
  public Message findById(@PathVariable Integer id) {
	  Message message = messageRepository.getOne(id);
    if (message == null) {
    	throw new MessageNotFoundException(id);
    }
    return message;
  }
  
  //@Secured("ROLE_ADMIN") 
  @RolesAllowed({"ROLE_ADMIN"})
  @RequestMapping(method=RequestMethod.POST, consumes="application/json")
  @ResponseStatus(HttpStatus.CREATED)
  public ResponseEntity<Message> saveJournal(@RequestBody Message message, UriComponentsBuilder ucb) {
    Message saved = messageRepository.save(message);
    
    HttpHeaders headers = new HttpHeaders();
    URI locationUri = ucb.path("api/messages/")
        .path(String.valueOf(saved.getId()))
        .build()
        .toUri();
    headers.setLocation(locationUri);
    
    ResponseEntity<Message> responseEntity = new ResponseEntity<Message>(saved, headers, HttpStatus.CREATED);
    return responseEntity;
  }
}
