# Beginning SpringBoot 2


### Chapter 13 : Securing Web Applications using SpringBoot

**springboot-thymeleaf-security-demo**: This module demonstrates how to secure a SpringBoot +Thymeleaf based web application using Spring Security.

#### How to run?

springboot-thymeleaf-security-demo> mvn spring-boot:run

Go to http://localhost:8080/

Login with admin@gmail.com/admin (or) user@gmail.com/user